//
//  ZMS.h
//  ZMS
//
//  Created by Sajal Kaushik on 03/09/21.
//

#import <Foundation/Foundation.h>

//! Project version number for ZMS.
FOUNDATION_EXPORT double ZMSVersionNumber;

//! Project version string for ZMS.
FOUNDATION_EXPORT const unsigned char ZMSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ZMS/PublicHeader.h>


